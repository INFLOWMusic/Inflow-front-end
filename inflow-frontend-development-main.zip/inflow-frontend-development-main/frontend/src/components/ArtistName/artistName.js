import React from 'react'

import './artistName'

const ArtistName = ({children, ...otherProps}) => {
    return (
        //import user from data base
        <div>
            {children}
        </div>
    )
}

export default ArtistName
