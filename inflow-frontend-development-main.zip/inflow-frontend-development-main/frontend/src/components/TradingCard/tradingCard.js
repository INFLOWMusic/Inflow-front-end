import React from 'react'
import './tradingCard.scss'

const TradingCard = () => {
    return (
        <div className='uniswap'>
            UniSwap Api
        </div>
    )
}

export default TradingCard
