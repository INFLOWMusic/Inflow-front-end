import React from 'react'

import './pieChart.scss'

const PieChart = () => {
    return (
        <div className='graph-card'>
            <h1>
                Pie Chart
            </h1>
        </div>
    )
}

export default PieChart
