import React from 'react'

import './worldMap.scss'

const WorldMap = () => {
    return (
        <div className='graph-card'>
            <h1>
                World Map
            </h1>
        </div>
    )
}

export default WorldMap
