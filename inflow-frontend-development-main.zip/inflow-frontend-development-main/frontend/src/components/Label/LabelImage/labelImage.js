import React from 'react'

import './labelImage.scss'

const LabelImage = () => {
    return (
        <div className='label-image'>
            Label Image
        </div>
    )
}

export default LabelImage
