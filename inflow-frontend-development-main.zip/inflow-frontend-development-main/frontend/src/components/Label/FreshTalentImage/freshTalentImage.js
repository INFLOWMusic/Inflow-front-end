import React from 'react'

import './freshTalentImage.scss'

const FreshTalentImage = () => {
    return (
        <div className='artist-to-sign-image'>
            <div>
                <img alt='Devy Stonez' src='https://img.particlenews.com/img/id/4UN1Eh_0OdCAwB600?type=thumbnail_800x800' />
            </div>
            <div>
                <img alt='Devy Stonez' src='https://img.particlenews.com/img/id/4UN1Eh_0OdCAwB600?type=thumbnail_800x800' />
            </div>
            <div>
                <img alt='Devy Stonez' src='https://img.particlenews.com/img/id/4UN1Eh_0OdCAwB600?type=thumbnail_800x800' />
            </div>
            <div>
                <img alt='Devy Stonez' src='https://img.particlenews.com/img/id/4UN1Eh_0OdCAwB600?type=thumbnail_800x800' />
            </div>
        </div>
    )
}

export default FreshTalentImage
