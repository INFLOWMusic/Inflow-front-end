import React from 'react'

import './labelPriceGraph.scss'

const LabelPriceGraph = () => {
    return (
        <div className='graph-card'>
            <h1>
                The Graph API
            </h1>
        </div>
    )
}

export default LabelPriceGraph
