const ArtistVideoData = [
    {
      video:
        'https://www.youtube.com/embed/1TW1VbInoxM'
    },
    {
      video:
        'https://www.youtube.com/embed/PLYi6SZwFVA'
    },
    {
      video:
        'https://www.youtube.com/embed/NJiJly6ldpI'
    }
  ];
  
  export default ArtistVideoData