 let HomeSlideShowData = [
  {
    image:
      'https://www.youtube.com/embed/1NhyFEZKq48'
  },
  {
    image:
      'https://www.youtube.com/embed/OE_dwXN_YHI'
  },
  {
    image:
      'https://www.youtube.com/embed/-bs1c-L-CUk'
  }
];

export default HomeSlideShowData
