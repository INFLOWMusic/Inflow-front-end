import React from 'react'

import './artistPriceGraph.scss'

const ArtistPriceGraph = () => {
    return (
        <div className='graph-card'>
            <h1>
                The Graph API
            </h1>
        </div>
    )
}

export default ArtistPriceGraph
